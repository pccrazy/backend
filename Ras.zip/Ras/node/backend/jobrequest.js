#!/usr/bin/node
var req=require('request');
var sleep=require('sleep');

require('crontab').load(function(err,crontab){
	
req.post({url:'http://10.8.0.1:3000/jobs',form:{user:'1'}},function(err,res,body){
	
	var jobs=JSON.parse(body);
    //console.log(jobs);
    for(var index in jobs){
	 
	update(jobs[index].idSecdualer);
	var job=crontab.create('/usr/bin/node /home/pi/node_modules/express/switcher.js '+jobs[index].DeviceStatus,jobs[index].Job);
     crontab.save(function(err,crontab){});
      } 	 
     
     });



});

function update(id)
{
 new req.post({url:'http://104.197.212.107:3000/updatejob',form:{id:id}},function(err,res,body){
			  
			  if(!err){
				  console.log(body);
				  }
			  
			  });

}

//{ idSecdualer: 1,idUser: 1,Job: '*/2 * * * *',Comment: 'job one ',device: '26', mode: 'on' }



