// monitors http request

var express    = require("express");
var bodyParser = require('body-parser');
var randomstring = require("randomstring");
var app = express();
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true }));
var tools=require("./Tools")
var gpio=require('gpio');

 app.post("/gpio",function(req,respond){
	 console.log(req.body.DN + " " + req.body.DM);
	 if(req.body.DN=="D1"){
		 
	gpio5=gpio.export(5,{
	direction:'out',interval:300,
	ready: function()
	{	if(req.body.DM=="0"){
		respond.send("0");
		   gpio5.set(0);	
		}else if(req.body.DM=="1")
		{
			respond.send("1");
		  gpio5.set(); 
		}
	}
	});}
	else if(req.body.DN=="D2"){
		 
	gpio5=gpio.export(6,{
	direction:'out',interval:300,
	ready: function()
	{	if(req.body.DM=="0"){
		      	respond.send("0");

		   gpio5.set(0);	

		}else if(req.body.DM=="1")
		{
		  respond.send("1");
		  gpio5.set(); 
		}
	}
	});
   }


 });
  app.post("/job",function(req,respond){
	
	 require('crontab').load(function(err,crontab){
	 //update(req.body.job);
	 var job=crontab.create('/usr/bin/node /home/pi/codes/node/backend/switcher.js '+req.body.dstatus,req.body.job);
     crontab.save(function(err,crontab){});
        
			 respond.send('ack');  	
			
     });
     respond.send('ack');     
    });
	
   function update(id)
   {    new req.post({url:'http://10.8.0.1:4000/updatejob',form:{id:id}},function(err,res,body){
			  
			  if(!err){
				  console.log(body);
				  }
			  
			  });

    }
 app.listen(4000);
