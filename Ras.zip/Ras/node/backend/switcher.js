#!/usr/bin/node 

var gpio=require('gpio');
gpio5=gpio.export(process.argv[2],{
	direction:'out',interval:300,
	ready: function()
	{	if(process.argv[3]=="off"){
		   gpio5.set(0);	
		}else if(process.argv[3]=="on")
		{
		  gpio5.set(); 
		}
	}
});
gpio6=gpio.export(process.argv[4],{
	direction:'out',interval:300,
	ready: function()
	{	if(process.argv[5]=="off"){
		   gpio6.set(0);	
		}else if(process.argv[5]=="on")
		{
		  gpio6.set(); 
		}
	}
});
gpio13=gpio.export(process.argv[6],{
	direction:'out',interval:300,
	ready: function()
	{	if(process.argv[7]=="off"){
		   gpio13.set(0);	
		}else if(process.argv[7]=="on")
		{
		  gpio13.set(); 
		}
	}
});
gpio26=gpio.export(process.argv[8],{
	direction:'out',interval:300,
	ready: function()
	{	if(process.argv[9]=="off"){
		   gpio26.set(0);	
		}else if(process.argv[9]=="on")
		{
		   gpio26.set(); 
		}
	}
});

