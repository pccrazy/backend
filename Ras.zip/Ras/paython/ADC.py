#!/usr/bin/python
import requests 
import spidev
import time
import os

# Open SPI bus
spi = spidev.SpiDev()
spi.open(0,0)
 
# Channel must be an integer 0-7
def ReadChannel(channel):
  adc = spi.xfer([1,(8+channel)<<4,0])
  data = ((adc[1]&3) << 8) + adc[2]
  return data 

# Define sensor channels
temp_channel  = 1
 
# Define delay between readings
delay = 60
 
while True:
  time.sleep(delay)
  # Read the temperature  sensor data
  temp_level = ReadChannel(temp_channel)
  volts = (350 * 1024)/temp_level
  temp = volts/100.00
  # Print out results
  print("%4.1f "%temp)
  try:
	  payload = {'temp':str("%4.1f "%temp),'user':'1'}
	  r=requests.post('http://10.8.0.1:3000/settemp', data=payload)
  # Wait before repeating loop
  except:
	  print("Somthing went worng")
