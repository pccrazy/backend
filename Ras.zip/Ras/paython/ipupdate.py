from subprocess import call
from threading import Thread
import netifaces 
from Queue import Queue
import socket
import fcntl
import struct
import requests 
import time

#update Remote Block 
def updateVpnRemote(ip):
	try:
		payload = {'user':'1','vpnip':ip}
		r=requests.post('http://104.236.253.6:3000/setremote', data=payload)
	except: 
		print('no internet')
	

def updateLocalRemote(ip):
	try:
		payload = {'user':'1','localip':ip}
		r=requests.post('http://104.236.253.6:3000/setlocal', data=payload)
	except:
		print('no internet')
		

			
			



#update block 
def get_ip_address(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,  # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])

def updatevpnlocaly(vpnip):
	updateVpnRemote(vpnip)
	vpn=open('/home/pi/codes/config/vpnip','r+')
	vpn.write(vpnip)
	vpn.close()
	
	
def updatewlanlocaly(wlanip):
	updateLocalRemote(wlanip)
	wlan=open('/home/pi/codes/config/wlanip','r+')
	wlan.write(wlanip)
	wlan.close()
	

#Action Block
def openvpn():
	command ='sudo killall -v openvpn & sh codes/scripts/openvpn.sh'
	call(command,shell=True)


# Current Ip Block 
def cvpn():
	cvpn=open('/home/pi/codes/config/vpnip','r+')
	cip=cvpn.read();
	cvpn.close()
	return cip

def cwlan():
	cwlan=open('/home/pi/codes/config/wlanip','r+')
	cip=cwlan.read()
	cwlan.close()
	return cip

	

# ip block 
def wlan():
	try:
		ip=get_ip_address('wlan0')
		if(ip != cwlan()):
			print ('you should update the ip')
			updatewlanlocaly(ip)
		
		print cwlan()
		print ip
		
	except:
		print 'wirless is down'
		#command ='sudo ifconfig wlan0 down & sudo ifconfig wlan0 up'
		#call(command.split(),shell=True)
	 
def vpn():
	try:
		vpnip=get_ip_address('tun0')
		if(vpnip != cvpn()):
			print('you should update the vpn')
			updatevpnlocaly(vpnip)
			
		print cvpn()
	except:
		print 'vpn is down'
		openvpn()
     

wlan()
vpn()

	
	
