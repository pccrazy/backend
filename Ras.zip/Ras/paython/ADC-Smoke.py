
#!/usr/bin/python
import requests 
import spidev
import time
import os
from threading import Thread
from Queue import Queue


def SendAlert():
	payload = {'user':'1'}
	r=requests.post('http://10.8.0.1:3000/alert', data=payload)
	return r
	

# Open SPI bus
spi = spidev.SpiDev()
spi.open(0,0)

# Function to read SPI data from MCP3008 chip
# Channel must be an integer 0-7
def ReadChannel(channel):
  adc = spi.xfer([1,(8+channel)<<4,0])
  data = ((adc[1]&3) << 8) + adc[2]
  return data 

# Define sensor channels
smoke_channel  = 2

# Define delay between readings
delay = 5
c = 0
while True:
  # Read the sensor data
  smoke_level = ReadChannel(smoke_channel)
  # Print out results
  print("%4.1f "%smoke_level)
  # send the push notification
  if smoke_level>=360:
	  print c
	  c += 1
  if c==5:
	  print("%4.1f "%smoke_level)
	  t = Thread(target=SendAlert)
	  t.daemon = True
	  t.start()
	  c = 0
  # Wait before repeating loop
  time.sleep(delay)

