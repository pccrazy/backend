#!/bin/bash
sudo /usr/sbin/openvpn /home/pi/codes/openvpnkey/ras.ovpn
